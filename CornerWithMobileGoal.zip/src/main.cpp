/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// LeftFront            motor         1               
// RightFront           motor         3               
// LeftBack             motor         7               
// RightBack            motor         4               
// Controller1          controller                    
// MobileGrab1          motor         20              
// MobileGrab2          motor         19              
// Intake1              motor         11              
// Intake2              motor         18              
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
  
}

void drive(int rev, int spd){

        LeftFront.rotateFor(rev, vex::rotationUnits::rev, spd, vex::velocityUnits::pct);
        LeftBack.rotateFor(rev, vex::rotationUnits::rev, spd, vex::velocityUnits::pct);
        RightBack.rotateFor(rev, vex::rotationUnits::rev, spd, vex::velocityUnits::pct);
        RightFront.rotateFor(rev, vex::rotationUnits::rev, spd, vex::velocityUnits::pct);
}
void LeftTurn90(int tme){
LeftBack.spinFor(tme, vex::timeUnits::msec, 100, vex::velocityUnits::pct);
LeftFront.spinFor(tme, vex::timeUnits::msec, 100, vex::velocityUnits::pct);
RightBack.spinFor(tme, vex::timeUnits::msec, 100, vex::velocityUnits::pct);
RightFront.spinFor(tme, vex::timeUnits::msec, 100, vex::velocityUnits::pct);
}
void RightTurn90(int tme){
  RightBack.spinFor(tme, vex::timeUnits::msec, 100, vex::velocityUnits::pct);
RightFront.spinFor(tme, vex::timeUnits::msec, 100, vex::velocityUnits::pct);
LeftBack.spinFor(tme, vex::timeUnits::msec, 100, vex::velocityUnits::pct);
LeftFront.spinFor(tme, vex::timeUnits::msec, 100, vex::velocityUnits::pct);
}
void MobileGrab1In(){
  MobileGrab1.spinFor(1000, vex::timeUnits::msec, 100, vex::velocityUnits::pct);
}
void MobileGrab1Out(){
MobileGrab1.spinFor(-1000, vex::timeUnits::msec, 100, vex::velocityUnits::pct);
}
void MobileGrab2In(){
  MobileGrab2.spinFor(1000, vex::timeUnits::msec, 100, vex::velocityUnits::pct);
}
void MobileGrab2Out(){
  MobileGrab2.spinFor(-1000, vex::timeUnits::msec, 100, vex::velocityUnits::pct);
}
void intake(int tme){
Intake1.spinFor(tme, vex::timeUnits::msec, 100, vex::velocityUnits::pct);
Intake2.spinFor(tme, vex::timeUnits::msec, 100, vex::velocityUnits::pct);
}
void outtake(int tme){
  Intake1.spinFor(tme, vex::timeUnits::msec, 100, vex::velocityUnits::pct);
Intake2.spinFor(tme, vex::timeUnits::msec, 100, vex::velocityUnits::pct);
}
void WideLeftTurn180(int tme){
LeftBack.spinFor(tme, vex::timeUnits::msec, 100, vex::velocityUnits::pct);
LeftFront.spinFor(tme, vex::timeUnits::msec, 100, vex::velocityUnits::pct);
}
void WideRightTurn180(int tme){
RightBack.spinFor(tme, vex::timeUnits::msec, 100, vex::velocityUnits::pct);
RightFront.spinFor(tme, vex::timeUnits::msec, 100, vex::velocityUnits::pct);
}
void stop(){
  RightBack.stop();
  LeftBack.stop();
  LeftFront.stop();
  RightFront.stop();
  MobileGrab1.stop();
  MobileGrab2.stop();
  Intake1.stop();
  Intake2.stop();
}
/*--------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous(void) {
  // ..........................................................................
  // Insert autonomous user code here.
  // ..........................................................................
 /* drive(-36/11, 100);
  stop();
  MobileGrab1In();
  stop();
LeftTurn90(570);
  stop();
  drive(24/11, 100);
  stop();
  RightTurn90(570);
  stop();
drive(3,100);
stop();
MobileGrab2In();
stop();
drive(-2,100);
MobileGrab1Out();
MobileGrab2Out();
stop();
LeftTurn90(570);
stop();
drive(1/2,100);
stop();
*/
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                     */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  
  // User control code here, inside the loop
  while (1) {
   
    // This is the main execution loop for the user control program.
    // Each time through the loop your program should update motor + servo
    // values based on feedback from the joysticks.

LeftFront.spin(vex::directionType::fwd, Controller1.Axis3.value(), vex::velocityUnits::rpm); 
        RightFront.spin(vex::directionType::fwd, Controller1.Axis2.value(), vex::velocityUnits::rpm);
        LeftBack.spin(vex::directionType::fwd, Controller1.Axis3.value(), vex::velocityUnits::rpm); 
        RightBack.spin(vex::directionType::fwd, Controller1.Axis2.value(), vex::velocityUnits::rpm);



 if (Controller1.ButtonX.pressing()) {
 Intake1.spin(vex::directionType::fwd, 20, vex::velocityUnits::pct);
 Intake2.spin(vex::directionType::fwd,20, vex::velocityUnits::pct);
 }
 else if(Controller1.ButtonB.pressing()){   
   Intake2.spin(vex::directionType::rev,20,vex::velocityUnits::pct);
   Intake1.spin(vex::directionType::rev,20,vex::velocityUnits::pct);
 }
  else{
    Intake1.stop(vex::brakeType::brake);
    Intake2.stop(vex::brakeType::brake);
  }

  if(Controller1.ButtonL1.pressing()){
 MobileGrab1.spin(vex::directionType::rev, 40, vex::velocityUnits::pct);
   }
   
   else if(Controller1.ButtonL2.pressing()){
     MobileGrab1.spin(vex::directionType::fwd, 20, vex::velocityUnits::pct);
   }
   else{
     MobileGrab1.stop(vex::brakeType::brake);
   }

   if(Controller1.ButtonR1.pressing()){
     MobileGrab2.spin(vex::directionType::rev, 40, vex::velocityUnits::pct);
   }

   else if(Controller1.ButtonR2.pressing()){
     MobileGrab2.spin(vex::directionType::fwd,20, vex::velocityUnits::pct);
   }
   else {
     MobileGrab2.stop(vex::brakeType::brake);
   }
    // ........................................................................
    // Insert user code here. This is where you use the joystick values to
    // update your motors, etc.
    // ........................................................................

    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
  }
}
//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();
 
  //(Axis3-Axis4)/2
  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);

  }
}

